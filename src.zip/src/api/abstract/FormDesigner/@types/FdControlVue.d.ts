interface FdControlVue {
    propControlData: controlData
}
